//Jennefer Fink
//February 7, 2026
//Airgead Banking App

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void displayScreen() { //function to display intitial screen. This function just displays the screen, does not allow for input
	cout << "Initial Investment Amount: " << endl;
	cout << "Monthly Deposit: " << endl;
	cout << "Annual Interest: " << endl;
	cout << "Number of Years: " << endl;
	cout << "Press and key to continue" << endl;
} //end function

void acceptUserInput() { //function to accept user input 
	double t_initialBalance = 0.0; //declaring variable
	double t_monthlyDeposit = 0.0; //declaring variable
	double t_annualInterestPercent = 0.0; //declaring variable
	int t_years = 0; //declaring variable
	char user_input = 'a'

	cout << "Please enter the initial investment amount" << endl;
	cin >> t_initialBalance; //user puts in intitial balance

	cout << "Please enter the monthly deposit amount" << endl;
	cin >> t_monthlyDeposit; //user inputs monthly deposit amount

	cout << "Please input the annual interest percent" << endl;
	cin >> t_annualInterestPercent; //user inputs the interest

	cout << "Please enter the number of years of the investment" << endl;
	cin >> t_years;// user inputs the number of years

	cout << "Please enter 'q' to quit" << endl;
	cin >> user_input; 

} //end function

void calculateBalance(double t_intitialBalance, double t_monthlyDeposit, double t_annualInterestPercent, int t_years)  //function to calculate compound interest
{
	const double monthlyRate = (t_annualInterestPercent / 100.0) / 12.0; //calculates the annual interest into monthly interest

	double balance = t_initialBalance; //setting balance equal to initial balance user inputs

	std::cout << "Year    Year End Balance    Year End Interest\n";
	std::cout << "- - - - - - - - - - - - - - - - - - - - - - - \n";

	for (int year = 1; year <= t_years; ++year) { //outer loop that processes each year of investment one at a time
		double yearInterest = 0.0; //to reset interest each year

		for (int month = 0; month < 12; ++month) { //inner loop to calculate compound interest each month
			double totalBeforeInterest = balance + t_monthlyDeposit; //adds monthly deposit to current balance
			double interest = totalBeforeInterest * monthlyRate;  //calculates interest after monthly deposit

			yearInterest += interest; //adds interest to annual interest
			balance = totalBeforeInterest + interest; //calculating the balance
		}

		std::cout << std::setw(4) << year
			<< "   $" << std::setw(15) << std::fixed << std::setprecision(2) << balance
			<< "   $" << std::setw(15) << std::fixed << std::setprecision(2) << yearInterest
			<< '\n';
	}


} //end function

main() { //main function where functions already established will be called
	char user_input = 'a'; //need to define user_input 
	double t_initialBalance = 0.0; //declaring variable
	double t_monthlyDeposit = 0.0; //declaring variable
	double t_annualInterestPercent = 0.0; //declaring variable
	int t_years = 0; //years is int and not double. Only variable that is int

	displayScreen(); //calling display screen function
	return 0; //displaying options to user
	
	 
	while (user_input != 'q') { //if user inputs q, quits otherwise runs the function to take user input
		acceptUserInput(); //calling function 
		return 0;//
		
		calculateBalance((t_initialBalance, /*monthlyDeposit=*/0.0, t_annualInterestPercent, t_years)); //without a monthly deposit

		calculateBalance(t_initialBalance, t_monthlyDeposit, t_annualInterestPercent, t_years); //with monthly deposit
		return 0; //print commands put in function, should display here
		 

	}
	
	return 0;

}
